@extends('layouts.admin')

@section('content')
    <h3 class="page-title">Medical Detail</h3>
    
    <div class="panel panel-default">
        <div class="panel-heading">
            View
            @include('includes.flash')
        </div>
        
        <div class="panel-body">
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-bordered table-striped">
                        <tr>
                            <th> Appointment ID </th>
                            <td>{{ $review->appointment_id }}</td>
                        </tr>
                        <tr>
                            <th> Rating </th>
                            
                            @if($review['userReview'])   
                            <td class="text-left">
                                <div class="stars starrr" data-rating="{{$review['userReview']->rating}}"></div>
                            </td>
                            @else
                            <td>Have not review/rated yet</td>
                            @endif

                        </tr>

                        <tr>
                            <th> Review </th>
                            <td>{{ ($review->review) ? $review->review : 'Have not review/rated yet' }}</td>
                        </tr>
                        
                        
                    <div class="container">

                        <div class="row" style="margin-top:40px;">
                            <div class="col-md-6">
                            <div class="well well-sm">
                                <div class="text-right">
                                    <a class="btn btn-success btn-green" href="javascript:void(0);" id="open-review-box">Leave a Review</a>
                                </div>
                            
                                <div class="row" id="post-review-box" style="display:none;">
                                 <div class="col-md-12">
                                
                                  <form accept-charset="UTF-8" method="POST" action="{{ route('admin.review.review', ['id'=> $review->appointment_id]) }}">
                                        
                                        {{ csrf_field() }}

                                            <input id="ratings-hidden" name="rating" type="hidden">
                                            <input id="appointment" name="appointment_id" value="{{$review->appointment_id}}" type="hidden"> 
                                            <textarea class="form-control animated" cols="50" id="new-review" name="comment" placeholder="Enter your review here..." rows="5"></textarea>
                            
                                            <div class="text-right">
                                                <div class="stars starrr" data-rating="0"></div>
                                                <a class="btn btn-danger btn-sm" href="#" id="close-review-box" style="display:none; margin-right: 10px;">
                                                <span class="glyphicon glyphicon-remove"></span>Cancel</a>
                                                <button class="btn btn-success btn-lg" type="submit">Save</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div> 
                             
                            </div>
                        </div>
                    </div>
                        
                    </table>
                </div>
            </div>

            <p>&nbsp;</p>

            <a href="{{ route('admin.review.index') }}" class="btn btn-default">Back to List</a>
        </div>
    </div>
@stop
